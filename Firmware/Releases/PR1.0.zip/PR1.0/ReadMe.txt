240808

-------------------------------------------------------------------------------
Author: Vishal Keshava Murthy 
Release: PR1.0
Code version: App : 1.0

-------------------------------------------------------------------------------

This folder contains the binaires for PR1.0 Fasal Flasher
The contents of the folder are as follows 

+---APP
¦   +---BUILD_DEBUG							: Debug binary with all debug symbols enabled and optimizations turned off 
¦   +---BUILD_PROD							: Prod binary for production floor use 
+---FasalFlasher_ReleaseNote.pdf			: Release note with usage instructions 
+---ReadMe.txt 								: This file 

-------------------------------------------------------------------------------

The binaires are taken from Tag PR1.0_V1.0 under the binaries folder here 
https://github.com/Fasal-Tech/FileFerry-Click2Flash

-------------------------------------------------------------------------------