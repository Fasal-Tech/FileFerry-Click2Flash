241206

-------------------------------------------------------------------------------
Author: Vishal Keshava Murthy 
Release: PR1.1
Code version: v1.1

-------------------------------------------------------------------------------

This folder contains the binaires for PR1.1 Fasal Flasher
The contents of the folder are as follows 

+---APP
¦   +---BUILD_DEBUG							: Debug binary with all debug symbols enabled and optimizations turned off 
¦   +---BUILD_PROD							: Prod binary for production floor use 
+---FasalFlasher_ReleaseNote.pdf			: Release note with testing instructions 
+---ReadMe.txt 								: This file 

-------------------------------------------------------------------------------

The binaires are taken from Tag PR1.1_V1.1 under the binaries folder here 
https://bitbucket.org/wolkustechnologysolutions/fasalflasher_firmware

-------------------------------------------------------------------------------